package my.com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import member.model.MemberDAO;

/**
 * Servlet implementation class MemberDeleteServlet
 */
@WebServlet("/MemberDelete")
public class MemberDeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse res) 
			throws ServletException, IOException {
		res.setContentType("text/html; charset=utf-8");
		PrintWriter out = res.getWriter();
		req.setCharacterEncoding("utf-8");
		String uid = req.getParameter("id"); // form.html에 있는 id
		
		//유효성 체크
		if(uid==null||uid.trim().isEmpty()) {
			out.println("<script>");
			out.println("alert('아이디를 입력하세요')");
			out.println("history.back();");//뒤로가기
			out.println("</script>");
			
			return;
		}
		//MemberDAO 객체 생성
		MemberDAO user = new MemberDAO();
		try {
			int n = user.deleteMember(uid);
			String msg = (n>0) ? "회원탈퇴가 완료되었습니다":"회원정보를 확인하세요";
			String loc = (n>0) ? "index.html":"member/mypage.html";
			out.println("<script>");
			out.println("alert('"+msg+"')");
			out.println("location.href='"+loc+"'");
			out.println("</script>");
		} catch (SQLException e) {
			out.println("<script>");
			out.println("alert('아이디가 없거나 서버에러입니다.')");
			out.println("history.back();");
			out.println("</script>");
			e.printStackTrace();
		}
		
	}//doGet

}

